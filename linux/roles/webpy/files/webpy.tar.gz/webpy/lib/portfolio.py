# coding: utf-8

import numpy as np
import pandas as pd
from datetime import datetime
from StringIO import StringIO
import json


pms_daily_template = './template/importWeight.sample.new.csv'
pms_initportfolio_tempalte = './template/account.positions.sample.csv'

# This function is only used for testing
def echo(data):
    df = pd.read_csv(data, encoding='GBK')
    print(df)
    return df.to_csv(index=False)


##############  核新同花顺-持仓导出 --->  pms初始持仓-创建组合
#读取本地文件，PMS初始持仓模板
def ths_pms_initportfolio(data):
    df_pms_form = pd.read_csv(pms_initportfolio_tempalte,encoding='GBK')
    df_pms_4 = df_pms_form[0:3]    #这是PMS初始持仓文件的头4行
    #读取核新同花顺持仓文件
    df_others = pd.read_csv(data, encoding='gbk',dtype={u'证券代码':np.str})
    #对文件进行筛选
    #df_others = df_others[df_others[u'证券代码'].apply(lambda x:x.isdigit())]    #筛选出股票
    df_others = df_others[[u'证券代码',u'股票余额',u'成本价',u'交易市场']]          #只取这几列数据
	
    #对文件进行处理，将导入文件处理成PMS认识的格式
    df_others.columns=[u'证券代码',u'持仓数量',u'成本价格',u'交易市场代码']
    df_others[u'持仓类型'] = 'LONG'
    df_others[u'交易市场代码'].replace({u'上海Ａ股':'XSHG', u'深圳Ａ股':'XSHE'},inplace=True)    #确定交易市场代码
    #df_new = pd.DataFrame({})
    #df_new[u'证券代码'] = df_others[u'证券代码']
    #df_new[u'交易市场代码'] = df_others[u'交易市场'].map(lambda x:'XSHG' if x==u'上海Ａ股' else 'XSHE')    #确定交易市场代码
    #df_new[u'持仓数量'] = df_others[u'股票余额']
    #df_new[u'成本价格'] = df_others[u'成本价']
    #df_new[u'持仓类型'] = 'LONG'
    #将文件进行调整，数据的拼合、列次序的固定，将内容写入到新的文档中
    df_all = pd.concat([df_pms_4,df_others])
    df_all = df_all.loc[:,[u'证券代码',u'交易市场代码',u'持仓类型',u'持仓数量',u'成本价格',u'投资类型']]
    print df_all
    io = StringIO()
    df_all.to_csv(io, encoding='gbk',index=False)
    return io.getvalue()


##############  核新同花顺-持仓导出 --->  pms完全调整持仓
def ths_pms_dailyportfolio(data):
    today = datetime.today()
    today_str = '/'.join([str(today.year),str(today.month),str(today.day)])

    #------读文件------
    #读取本地文件，PMS完全调整持仓模板
    df_pms_form = pd.read_csv(pms_daily_template,encoding='GBK')
    df_pms_4 = df_pms_form[0:3]    #这是PMS完全调整持仓模板的头4行
    #读取核新同花顺持仓文件
    df_others = pd.read_csv(data, encoding='gbk',dtype={u'证券代码':np.str})

    #对文件进行筛选
    #df_others = df_others[df_others[u'证券代码'].apply(lambda x:x.isdigit())]    #筛选出股票
    df_others = df_others[[u'证券代码',u'股票余额',u'成本价',u'交易市场']]          #只取这几列数据
    #对文件进行处理，将导入文件处理成PMS认识的格式
    df_others.columns=[u'证券代码',u'持仓数量',u'成本价格',u'交易市场代码']
    df_others[u'持仓类型'] = 'LONG'
    df_others[u'数量模式'] = 'QUANTITY'
    df_others[u'日期'] = today_str
    df_others[u'交易市场代码'].replace({u'上海Ａ股':'XSHG', u'深圳Ａ股':'XSHE'},inplace=True)    #确定交易市场代码
    #df_new = pd.DataFrame({})
    #df_new[u'证券代码'] = df_others[u'证券代码']
    #df_new[u'交易市场代码'] = df_others[u'交易市场'].map(lambda x:'XSHG' if x==u'上海Ａ股' else 'XSHE')    #确定交易市场代码
    #df_new[u'持仓数量'] = df_others[u'股票余额']
    #df_new[u'成本价格'] = df_others[u'成本价']
    #df_new[u'持仓类型'] = 'LONG'
    #df_new[u'日期'] = today_str

    #将文件进行调整，数据的拼合、列次序的固定，将内容写入到新的文档中
    df_all = pd.concat([df_pms_4,df_others])
    df_all = df_all.loc[:,[u'日期',u'证券代码',u'交易市场代码',u'持仓类型',u'持仓数量',u'数量模式',u'成本价格',u'投资类型']]
    io = StringIO()
    df_all.to_csv(io, encoding='gbk',index=False)
    return io.getvalue()


##############  通达信-持仓导出 --->  pms初始持仓-创建组合
#------读文件------
#读取本地文件，PMS初始持仓模板
def tdx_pms_initportfolio(data):
    df_pms_form = pd.read_csv(pms_initportfolio_tempalte,encoding='GBK')
    df_pms_4 = df_pms_form[0:3]    #这是PMS初始持仓文件的头4行
    #读取通达信持仓文件
    df_others = pd.read_table(data, encoding='gbk',skiprows=3,dtype={u'证券代码':np.str})    #忽略头3行

    #对文件进行筛选
    #df_others = df_others[df_others[u'证券代码'].apply(lambda x:x.isdigit())]    #筛选出股票
    df_others = df_others[[u'证券代码',u'证券数量',u'成本价']]          #只取这几列数据
	
    #对文件进行处理，将导入文件处理成PMS认识的格式
    df_others.columns=[u'证券代码',u'持仓数量',u'成本价格']
    df_others[u'持仓类型'] = 'LONG'
    df_others[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    #df_new = pd.DataFrame({})
    #df_new[u'证券代码'] = df_others[u'证券代码']
    #df_new[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    #df_new[u'持仓数量'] = df_others[u'证券数量']
    #df_new[u'成本价格'] = df_others[u'成本价']
    #df_new[u'持仓类型'] = 'LONG'

    #将文件进行调整，数据的拼合、列次序的固定，将内容写入到新的文档中
    df_all = pd.concat([df_pms_4,df_others])
    df_all = df_all.loc[:,[u'证券代码',u'交易市场代码',u'持仓类型',u'持仓数量',u'成本价格',u'投资类型']]
    io = StringIO()
    df_all.to_csv(io, encoding='gbk',index=False)
    return io.getvalue()




##############  通达信-持仓导出 --->  pms完全调整持仓
def tdx_pms_dailyportfolio(data):
    today = datetime.today()
    today_str = '/'.join([str(today.year),str(today.month),str(today.day)])

    #------读文件------
    #读取本地文件，PMS完全调整持仓模板
    df_pms_form = pd.read_csv(pms_daily_template,encoding='GBK')
    df_pms_4 = df_pms_form[0:3]    #这是PMS完全调整持仓模板的头4行
    #读取通达信持仓文件
    df_others = pd.read_table(data, encoding='gbk',skiprows=3,dtype={u'证券代码':np.str})    #忽略头3行

    #对文件进行筛选
    #df_others = df_others[df_others[u'证券代码'].apply(lambda x:x.isdigit())]    #筛选出股票
    df_others = df_others[[u'证券代码',u'证券数量',u'成本价']]          #只取这几列数据
	
    #对文件进行处理，将导入文件处理成PMS认识的格式
    df_others.columns=[u'证券代码',u'持仓数量',u'成本价格']
    df_others[u'持仓类型'] = 'LONG'
    df_others[u'数量模式'] = 'QUANTITY'
    df_others[u'日期'] = today_str
    df_others[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    #df_new = pd.DataFrame({})
    #df_new[u'证券代码'] = df_others[u'证券代码']
    #df_new[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    #df_new[u'持仓数量'] = df_others[u'证券数量']
    #df_new[u'成本价格'] = df_others[u'成本价']
    #df_new[u'持仓类型'] = 'LONG'
    #df_new[u'日期'] = today_str

    #将文件进行调整，数据的拼合、列次序的固定，将内容写入到新的文档中
    df_all = pd.concat([df_pms_4,df_others])
    df_all = df_all.loc[:,[u'日期',u'证券代码',u'交易市场代码',u'持仓类型',u'持仓数量',u'数量模式',u'成本价格',u'投资类型']]
    io = StringIO()
    df_all.to_csv(io, encoding='gbk',index=False)
    return io.getvalue()
