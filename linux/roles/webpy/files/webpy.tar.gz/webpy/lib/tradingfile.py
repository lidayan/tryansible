# coding: utf-8

import numpy as np
import pandas as pd
from StringIO import StringIO

pms_template_csv = './template/account.trades.sample.csv'

##############  核新同花顺-交割单 --->  pms历史交易模板
def ths_pms_historytrading(data):
    #------读文件------
    #读取本地文件，PMS初始持仓模板
    df_pms_form = pd.read_csv(pms_template_csv, encoding='GBK')
    df_pms_4 = df_pms_form[0:3]    #这是历史交易文件的头4行
    #读取核新同花交割单文件
    df_others = pd.read_csv(data, encoding='gbk',dtype={u'证券代码':np.str,u'成交日期':np.str})
    #对文件进行筛选
    #df_others = df_others[df_others[u'证券代码'].apply(lambda x:str.isdigit(x))]    #筛选出股票
    df_others = df_others[[u'成交日期',u'证券代码',u'操作',u'成交数量',u'成交均价']]          #只取这几列数据

    #处理日期
    def change_date(x):
        year = x[0:4]
        month = x[4:6] if x[4]!='0' else x[4]
        day = x[6:8] if x[6]!='0' else x[6]
        new_date = '/'.join([year,month,day])
        return new_date
    
    def change_tradeSide(x):
        tradeSide = x
        if x==u'买':tradeSide='BUY'
        elif x==u'卖':tradeSide='SELL'
        return tradeSide
    	

    #对文件进行处理，将导入文件处理成PMS认识的格式
    df_others.columns=[u'日期',u'证券代码',u'交易方向',u'交易数量',u'交易价格']
    df_others[u'价格模式'] = 'INPUT_PRICE'
    df_others[u'日期'] = df_others[u'日期']
    df_others[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    df_others[u'交易方向'] = df_others[u'交易方向'].map(change_tradeSide)
    #df_new = pd.DataFrame({})
    #df_new[u'日期'] = df_others[u'成交日期'].map(change_date)
    #df_new[u'证券代码'] = df_others[u'证券代码']
    #df_new[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    #df_new[u'交易方向'] = df_others[u'操作'].map(lambda x: 'BUY' if x==u'买' else 'SELL')
    #df_new[u'交易数量'] = df_others[u'成交数量']
    #df_new[u'交易价格'] = df_others[u'成交均价']
    #df_new[u'价格模式'] = 'INPUT_PRICE'

    #将文件进行调整，数据的拼合、列次序的固定，将内容写入到新的文档中
    df_all = pd.concat([df_pms_4,df_others])
    df_all = df_all.loc[:,[u'日期',u'证券代码',u'交易市场代码',u'交易方向',u'交易数量',u'交易价格',u'价格模式',u'投资类型']]
    io = StringIO()
    df_all.to_csv(io, encoding='gbk',index=False)
    return io.getvalue()


# In[2]:
def ths_pms_dailytrading(data):
    ##############  核新同花顺-交割单 --->  pms日常交易模板
    #------读文件------
    #读取本地文件，PMS初始持仓模板
    df_pms_form = pd.read_csv(pms_template_csv,encoding='GBK')
    df_pms_4 = df_pms_form[0:3]    #这是PMS日常交易的头4行
    #读取核新同花顺交割单文件
    df_others = pd.read_csv(data, encoding='gbk',dtype={u'证券代码':np.str,u'成交日期':np.str})

    #对文件进行筛选
    #df_others = df_others[df_others[u'证券代码'].apply(lambda x:x.isdigit())]    #筛选出股票
    df_others = df_others[[u'成交日期',u'证券代码',u'操作',u'成交数量',u'成交均价']]          #只取这几列数据

    #处理日期
    def change_date(x):
        year = x[0:4]
        month = x[4:6] if x[4]!='0' else x[4]
        day = x[6:8] if x[6]!='0' else x[6]
        new_date = '/'.join([year,month,day])
        return new_date
		    
    def change_tradeSide(x):
        tradeSide = x
        if x==u'买':tradeSide='BUY'
        elif x==u'卖':tradeSide='SELL'
        return tradeSide

    #对文件进行处理，将导入文件处理成PMS认识的格式
    df_others.columns=[u'日期',u'证券代码',u'交易方向',u'交易数量',u'交易价格']
    df_others[u'价格模式'] = 'INPUT_PRICE'
    df_others[u'日期'] = df_others[u'日期']
    df_others[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    df_others[u'交易方向'] = df_others[u'交易方向'].map(change_tradeSide)
    #df_new = pd.DataFrame({})
    #df_new[u'日期'] = df_others[u'成交日期'].map(change_date)
    #df_new[u'证券代码'] = df_others[u'证券代码']
    #df_new[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    #df_new[u'交易方向'] = df_others[u'操作'].map(lambda x: 'BUY' if x==u'买' else 'SELL')
    #df_new[u'交易数量'] = df_others[u'成交数量']
    #df_new[u'交易价格'] = df_others[u'成交均价']
    #df_new[u'价格模式'] = 'INPUT_PRICE'

    #将文件进行调整，数据的拼合、列次序的固定，将内容写入到新的文档中
    df_all = pd.concat([df_pms_4,df_others])
    df_all = df_all.loc[:,[u'日期',u'证券代码',u'交易市场代码',u'交易方向',u'交易数量',u'交易价格',u'价格模式',u'投资类型']]
    io = StringIO()
    df_all.to_csv(io, encoding='gbk',index=False)
    return io.getvalue()


##############  通达信-交割单 --->  pms历史交易模板
def tdx_pms_historytrading(data):
    #------读文件------
    #读取本地文件，PMS历史交易模板
    df_pms_form = pd.read_csv(pms_template_csv,encoding='GBK')
    df_pms_4 = df_pms_form[0:3]    #这是PMS历史交易模板的头4行
    #读取通达信持仓文件
    df_others = pd.read_table(data, encoding='gbk',dtype={u'证券代码':np.str,u'成交日期':np.str})

    #对文件进行筛选
    #df_others = df_others[df_others[u'证券代码'].apply(lambda x:x.isdigit())]    #筛选出股票
    df_others = df_others[[u'成交日期',u'证券代码',u'操作',u'成交数量',u'成交价格']]          #只取这几列数据

    #处理日期
    def change_date(x):
        year = x[0:4]
        month = x[4:6] if x[4]!='0' else x[4]
        day = x[6:8] if x[6]!='0' else x[6]
        new_date = '/'.join([year,month,day])
        return new_date
		
    def change_tradeSide(x):
        tradeSide = x
        if x==u'买':tradeSide='BUY'
        elif x==u'卖':tradeSide='SELL'
        return tradeSide

    #对文件进行处理，将导入文件处理成PMS认识的格式
    df_others.columns=[u'日期',u'证券代码',u'交易方向',u'交易数量',u'交易价格']
    df_others[u'价格模式'] = 'INPUT_PRICE'
    df_others[u'日期'] = df_others[u'日期']
    df_others[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    df_others[u'交易方向'] = df_others[u'交易方向'].map(change_tradeSide)
    #df_new = pd.DataFrame({})
    #df_new[u'日期'] = df_others[u'成交日期'].map(change_date)
    #df_new[u'证券代码'] = df_others[u'证券代码']
    #df_new[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    #df_new[u'交易方向'] = df_others[u'操作'].map(lambda x: 'BUY' if x==u'买' else 'SELL')
    #df_new[u'交易数量'] = df_others[u'成交数量']
    #df_new[u'交易价格'] = df_others[u'成交价格']
    #df_new[u'价格模式'] = 'INPUT_PRICE'

    #将文件进行调整，数据的拼合、列次序的固定，将内容写入到新的文档中
    df_all = pd.concat([df_pms_4,df_others])
    df_all = df_all.loc[:,[u'日期',u'证券代码',u'交易市场代码',u'交易方向',u'交易数量',u'交易价格',u'价格模式',u'投资类型']]
    io = StringIO()
    df_all.to_csv(io, encoding='gbk',index=False)
    return io.getvalue()


def tdx_pms_dailytrading(data):
    ##############  通达信-交割单 --->  pms日常交易模板
    #------读文件------
    #读取本地文件，pms日常交易模板
    df_pms_form = pd.read_csv(pms_template_csv,encoding='GBK')
    df_pms_4 = df_pms_form[0:3]    #这是pms日常交易模板的头4行
    #读取通达信持仓文件
    df_others = pd.read_table(data, encoding='gbk',dtype={u'证券代码':np.str,u'成交日期':np.str})

    #对文件进行筛选
    #df_others = df_others[df_others[u'证券代码'].apply(lambda x:x.isdigit())]    #筛选出股票
    df_others = df_others[[u'成交日期',u'证券代码',u'操作',u'成交数量',u'成交价格']]          #只取这几列数据

    #处理日期
    def change_date(x):
        year = x[0:4]
        month = x[4:6] if x[4]!='0' else x[4]
        day = x[6:8] if x[6]!='0' else x[6]
        new_date = '/'.join([year,month,day])
        return new_date
    def change_tradeSide(x):
        tradeSide = x
        if x==u'买':tradeSide='BUY'
        elif x==u'卖':tradeSide='SELL'
        return tradeSide
    #对文件进行处理，将导入文件处理成PMS认识的格式
    df_others.columns=[u'日期',u'证券代码',u'交易方向',u'交易数量',u'交易价格']
    df_others[u'价格模式'] = 'INPUT_PRICE'
    df_others[u'日期'] = df_others[u'日期']
    df_others[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    df_others[u'交易方向'] = df_others[u'交易方向'].map(change_tradeSide)
    #df_new = pd.DataFrame({})
    #df_new[u'日期'] = df_others[u'成交日期'].map(change_date)
    #df_new[u'证券代码'] = df_others[u'证券代码']
    #df_new[u'交易市场代码'] = df_others[u'证券代码'].map(lambda x:'XSHG' if (x[0]=='6' and len(x)==6) else 'XSHE')    #确定交易市场代码
    #df_new[u'交易方向'] = df_others[u'操作'].map(lambda x: 'BUY' if x==u'买' else 'SELL')
    #df_new[u'交易数量'] = df_others[u'成交数量']
    #df_new[u'交易价格'] = df_others[u'成交价格']
    #df_new[u'价格模式'] = 'INPUT_PRICE'

    #将文件进行调整，数据的拼合、列次序的固定，将内容写入到新的文档中
    df_all = pd.concat([df_pms_4,df_others])
    df_all = df_all.loc[:,[u'日期',u'证券代码',u'交易市场代码',u'交易方向',u'交易数量',u'交易价格',u'价格模式',u'投资类型']]
    io = StringIO()
    df_all.to_csv(io, encoding='gbk',index=False)
    return io.getvalue()
