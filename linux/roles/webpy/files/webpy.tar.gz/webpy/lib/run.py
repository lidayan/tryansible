# -*- coding=utf-8 -*-

import json
from StringIO import StringIO
from flask import Flask, request, jsonify,send_file,Response

app = Flask(__name__)

modules = {}

formats = [
    {
        'vender': 'ths',
        'vender_name': '核新同花顺',
        'formats': [
            'INIT_POSITION',
            'DAILY_POSITION',
            'HISTORY_TRADE',
            'DAILY_TRADE'
        ]
    },
    {
        'vender': 'tdx',
        'vender_name': '通达信',
        'formats': [
            'INIT_POSITION',
            'DAILY_POSITION',
            'HISTORY_TRADE',
            'DAILY_TRADE'
        ]
    }
]

converters = {
    'ths': {
        'ECHO': ['portfolio', 'echo'],  # This is for test
        'INIT_POSITION': ['portfolio', 'ths_pms_initportfolio'],
        'DAILY_POSITION': ['portfolio', 'ths_pms_dailyportfolio'],
        'HISTORY_TRADE': ['tradingfile', 'ths_pms_historytrading'],
        'DAILY_TRADE': ['tradingfile', 'ths_pms_dailytrading']
    },
    'tdx': {
        'INIT_POSITION': ['portfolio', 'tdx_pms_initportfolio'],
        'DAILY_POSITION': ['portfolio', 'tdx_pms_dailyportfolio'],
        'HISTORY_TRADE': ['tradingfile', 'tdx_pms_historytrading'],
        'DAILY_TRADE': ['tradingfile', 'tdx_pms_dailytrading']
    }
}

@app.route('/formats', methods=['GET'])
def supported_formats():
    data = {'formats': formats}
    return jsonify(data)


@app.route('/convert/<vender>/<fmt>', methods=['POST'])
def convert(vender, fmt):
    [module, func] = converters[vender][fmt]
    #csv_file = request.files['pms_file']
    #data = StringIO(csv_file.read())
    data = StringIO(request.data)
    m = get_module_by_name(module)
    f = getattr(m, func)
    return_data = f(data)
    return Response(return_data,content_type='text/csv;charset=gbk')

#@app.route('/convert/<vender>/<fmt>', methods=['POST'])
#def convert(vender, fmt):
#    # pms_file 由pms发送时指定
#    csv_file = request.files['pms_file']
#    csv_data = StringIO(csv_file.read())
#    # 示例：核新同花顺-持仓导出 --->  pms初始持仓-创建组合
#    return_data = portfolio.echo(csv_data)
#    return return_data


def get_module_by_name(n):
    if modules.has_key(n):
        return modules[n]
    else:
        m = __import__(n)
        modules[n] = m
        return m



if __name__ == "__main__":
    app.run(host='0.0.0.0',port=1234, debug=True)
